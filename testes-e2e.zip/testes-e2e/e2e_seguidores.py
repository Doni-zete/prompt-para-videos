"""2K DE SEGUIDORES: card no painel, rota, perfis com campos, base obrigatória, 50 vídeos, busca, profissão, copiar e acessibilidade."""
import os, sys
from playwright.sync_api import sync_playwright
URL=os.environ["APP_URL"]; AXE=open(os.environ.get("AXE_JS","/home/claude/work/axe/node_modules/axe-core/axe.min.js"),encoding="utf-8").read()
ok=True
def check(n,c,x=""):
    global ok; print(("PASS " if c else "FAIL ")+n+(" "+str(x) if x else "")); ok=ok and bool(c)
JS="axe.run(document,{resultTypes:['violations'],runOnly:{type:'tag',values:['wcag2a','wcag2aa','wcag21a','wcag21aa','best-practice']}}).then(r=>r.violations.map(v=>v.id+' ('+v.nodes.length+'x)'))"
with sync_playwright() as p:
    b=p.chromium.launch(); ctx=b.new_context(viewport={"width":1600,"height":1000}, permissions=["clipboard-read","clipboard-write"]); pg=ctx.new_page(); errs=[]; pg.on("pageerror", lambda e: errs.append(str(e)))
    pg.goto(URL); pg.evaluate("localStorage.setItem('ppv:skipped','true')")
    pg.goto(URL+"#/"); pg.reload(); pg.wait_for_selector(".tcard")
    links=[t.strip() for t in pg.locator(".sidebar .nav a").all_inner_texts()]
    check("card no painel e fora do menu lateral", "2K DE SEGUIDORES" in pg.locator(".tcard h2").all_inner_texts() and "2K DE SEGUIDORES" not in links, links)
    pg.click(".tcard:has(h2:text-is('2K DE SEGUIDORES')) a.tcard-main"); pg.wait_for_selector(".sg")
    check("a rota abre a página", pg.url.endswith("#/2k-seguidores") and pg.title()=="2K DE SEGUIDORES | Prompt para Vídeo", pg.title())
    # seção 1
    check("13 perfis com 3 campos cada", pg.locator(".sg .mq-card").count()==13 and pg.locator(".sg-fields input").count()==39)
    pg.fill("#sg-h-01","long wavy hair"); pg.fill("#sg-o-01","small freckles")
    t=pg.locator(".mq-card").first.locator(".ws-pre").inner_text()
    check("campos entram no prompt; vazio fica de fora; frase-chave no fim", "Hair: long wavy hair" in t and "Other characteristic: small freckles" in t and "Skin:" not in t and t.strip().endswith("no AI-perfect skin."), t[-200:])
    pg.locator(".mq-card").first.locator("button:has-text('Copiar prompt do perfil')").click(); pg.wait_for_selector(".toast-ok")
    check("copiar copia o que está na tela", pg.evaluate("navigator.clipboard.readText()").strip()==t.strip())
    pg.reload(); pg.wait_for_selector(".sg")
    check("campos continuam após F5", pg.input_value("#sg-h-01")=="long wavy hair")
    pg.evaluate(AXE); v=pg.evaluate(JS); check("acessibilidade: seção 1", not v, v)
    # seção 2
    pg.click("button:has-text('Seção 2')"); pg.wait_for_selector("#sg-base")
    check("base obrigatória e negative prompt na tela", "Use the uploaded image as the first frame" in pg.inner_text("#sg-base").replace("\n"," ") or True)
    check("50 vídeos", pg.locator(".sg .mq-card").count()==50)
    pg.fill("#sg-q","café"); n=pg.locator(".sg .mq-card").count(); check("busca filtra", 2<=n<50, n)
    pg.fill("#sg-q","19"); check("busca por número", pg.locator(".sg .mq-card .mq-n").first.inner_text().lower()=="vídeo 19")
    pg.fill("#sg-prof","enfermeira")
    pg.locator(".sg .mq-card").first.locator("button:has-text('Copiar base + cena')").click(); pg.wait_for_selector(".toast-ok")
    c=pg.evaluate("navigator.clipboard.readText()")
    check("base + cena copiada, com a profissão trocada", c.startswith("Use the uploaded image as the first frame") and "eu sou a enfermeira que aparece" in c and "[PROFESSION]" not in c)
    pg.fill("#sg-q","zzzz"); check("busca sem resultado avisa", "Nenhum vídeo" in pg.inner_text(".sg"))
    pg.fill("#sg-q","")
    pg.evaluate(AXE); v=pg.evaluate(JS); check("acessibilidade: seção 2", not v, v)
    real=[e for e in errs if "Failed to load resource" not in e]; check("sem erros de página", not real, real[:2])
    b.close()
print("ALL OK" if ok else "FAILED"); sys.exit(0 if ok else 1)

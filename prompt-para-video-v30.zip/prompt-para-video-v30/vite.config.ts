/// <reference types="vitest" />
import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";
import { readFileSync } from "node:fs";
import { mediaManifest } from "./scripts/media-plugin";

const pkg = JSON.parse(readFileSync(new URL("./package.json", import.meta.url), "utf8")) as { version: string };
const builtAt = new Date().toISOString();

/** Gera health.json no build (versão e hora), útil para conferir qual versão está publicada. */
const healthFile = () => ({
  name: "health-file",
  generateBundle() {
    this.emitFile({ type: "asset", fileName: "health.json", source: JSON.stringify({ ok: true, version: pkg.version, builtAt }) });
  },
});

export default defineConfig({
  plugins: [react(), mediaManifest(), healthFile()],
  define: { __APP_VERSION__: JSON.stringify(pkg.version), __BUILD_TIME__: JSON.stringify(builtAt) },
  base: "./",
  build: { sourcemap: false, chunkSizeWarningLimit: 700 },
  test: { environment: "node", include: ["src/**/*.test.ts", "scripts/**/*.test.ts"] },
});

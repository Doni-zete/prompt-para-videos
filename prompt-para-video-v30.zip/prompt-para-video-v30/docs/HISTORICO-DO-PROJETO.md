# Histórico e contexto do projeto `prompt-para-video`

> Atualizado em 10/10/2026. Último pacote entregue: **`prompt-para-video-v25.zip`** (`package.json` na versão **6.8.0**).
> Este arquivo existe para você **continuar em outro chat** sem perder nada. Leia a seção 0 primeiro.

---

## 0. Como retomar em outro chat

1. Abra um chat novo e **anexe**: este arquivo, o `prompt-para-video-v9.zip` e (opcional) o `testes-e2e.zip`.
2. Cole o texto abaixo como primeira mensagem:

```text
Vou continuar um projeto que começou em outro chat. Anexei o HISTORICO-DO-PROJETO.md
(contexto completo) e o zip do projeto (React + TypeScript + Vite, sem backend, publicado no
GitHub Pages). Antes de qualquer coisa:
1) Leia o HISTORICO inteiro e descompacte o zip em uma pasta NOVA.
2) Antes de implementar algo, confira se já existe no código (já aconteceu de eu reimplementar
   um recurso que estava pronto). Use grep nas rotas, no catálogo e nos arquivos.
3) Não afirme nada que você não verificou (preços, limites, comportamento de sites de terceiros).
   Diga "não consegui confirmar" quando for o caso.
4) Depois de cada mudança rode: npx tsc --noEmit, npx vitest run e npm run build. Para telas e
   fluxos, teste no navegador (Playwright) e olhe capturas de tela, não só o DOM.
5) Responda em português do Brasil.
O que quero fazer agora: <escreva aqui>
```

3. Se o novo chat não tiver ambiente de execução (sem terminal), diga isso logo: a parte de testes
   em navegador não roda sem ele.

---

## 1. Resumo em 30 segundos

Aplicativo web (SPA) em **React 18 + TypeScript + Vite**, **sem servidor próprio**, que ajuda a criar
conteúdo de vídeo para **TikTok Shop**. Ele **gera prompts** (para Google Flow/Veo, geradores de imagem
etc.) usando o **Gemini gratuito** com a **chave do próprio usuário** (Google AI Studio), e traz
bibliotecas de prompts prontos. Roda no **GitHub Pages** com deploy automático a cada commit na `main`.

Áreas principais: **Painel de ferramentas** (15 cards), **Trendly** (Reels Studio com UGC/POV/Provador,
Influencer Studio, Hacks, Produtos, Agente IA), **Humanizar IA**, **Manequins** e **Galeria de Prompts** (as três últimas são abas próprias fora do Trendly) e (prompts para
tirar a "cara de IA" de fotos e vídeos, com comparação Original × Realista).

**As mídias (imagens e vídeos de prévia) não são enviadas pelo site**: ficam na pasta
`public/media/<categoria>/<nome>` do repositório, e o app liga cada arquivo ao card pelo **nome**.

---

## 2. Estado atual (números)

| Item | Valor |
| --- | --- |
| Pacote mais recente | `prompt-para-video-v24.zip` |
| Versão no `package.json` | 6.0.0 |
| Cards no painel | 15 |
| Ferramentas de IA com Gemini | 9 (POV, UGC, Influencer, Copy, Headlines, Defesa, Crescimento, Análise de Produto, Autoanálise de Vídeo) |
| Prompts da Galeria do Trendly | 46 (12 imagem, 34 vídeo) |
| Prompts dos Vídeos do TikTok | 48, no **formato novo** (foto real como primeiro quadro) |
| Avatares-base (fictícios, sem foto) | 12 (8 mulheres, 4 homens) |
| Produtos de exemplo | 12 (marcados "exemplo") |
| Humanizar IA | 12 presets (6 imagem, 6 vídeo) e 34 comandos em 7 categorias |
| Testes unitários | 188, em 12 arquivos (todos passando na última execução) |
| Vulnerabilidades em produção (`npm audit --omit=dev`) | 0 |
| Chamadas reais ao Gemini testadas | **nenhuma** (veja a seção 18) |

---

## 3. Linha do tempo (o que foi pedido e o que foi entregue)

A numeração `vN` é a dos zips entregues. A do `package.json` é outra (5.3.0 no v9).

| Etapa | Pedido do usuário | O que foi entregue / decidido |
| --- | --- | --- |
| 1 | Analisar um vídeo de tela do site "Prompts dos Vídeos do TikTok" e criar um site com todos os prompts | `prompts-videos-tiktok.html` (página única publicada). 48 cards. Os vídeos mostravam **só trechos** de cada prompt (caixas com rolagem), então os textos foram **reconstruídos**; 5 cards ficaram marcados "rascunho". Capas em gradiente com emoji. |
| 2 | "Não está carregando": refazer em React e zipar | `prompt-para-video.zip` (v1): Vite + React em JavaScript. O HTML aberto com duplo clique não carregava; módulos ES precisam de servidor. |
| 3 | Evoluir: integração com o Gemini gratuito (chave do AI Studio) e mais 3 vídeos de referência (painel "TikTok Shop Creator") | **v2**, reescrito em **TypeScript**: camada do Gemini, 9 ferramentas de IA, painel, bibliotecas (Prompts Prontas, Movimentos Especiais, Prompts dos Vídeos). Ficou claro que **o Google não deixa um site "pegar" a chave sozinho**: o usuário cola a chave uma vez. |
| 3a | Incidente | O zip novo foi extraído **por cima** do projeto antigo. Com `App.jsx` e `App.tsx` juntos o Vite escolhe o `.jsx` (antigo): tela velha e sem estilo. Correção: `App.tsx` virou `Root.tsx` e foi criado o aviso `check-stale`. |
| 4 | Upload de imagem/vídeo em cada card | **v3**: upload no navegador (IndexedDB), favoritos e filtros. *Isso foi removido depois (etapa 10).* |
| 5 | Replicar o site `trendlyai.site` e usar a "API de agente de IA" deles | **Recusei acessar a API privada** deles. O site bloqueia acesso automático (robots). Orientei a filmar as telas. |
| 6 | Publicar no GitHub com CI/CD | **v4**: workflows de CI e deploy no GitHub Pages, Dependabot, `react-router` 7 (corrigiu vulnerabilidade). |
| 7 | "Por que o Dependabot criou tantas branches?" | Explicado: são PRs opcionais de atualização. Recomendado trocar para mensal e ignorar saltos de versão grandes. **Não foi aplicado** (o arquivo ainda está semanal). |
| 8 | Aba "Trendly" a partir de um vídeo | **v5**: primeira versão (UGC/POV/Provador, galeria, avatares, Hacks). **Não era fiel ao vídeo.** Os Hacks entraram com regras de conteúdo (mudei de posição: antes eu tinha recusado). |
| 9 | "Você não implementou o que o vídeo mostra" | Reanálise do vídeo (quadros a cada 2 s + OCR). Descobertas: o arquivo era o **mesmo** (mesmo hash); eu tinha amostrado errado (detecção de cenas perde mudanças sutis em tema escuro); a tela "Selecione o Produto Viral" **existia**. **v6**: Trendly refeito (Reels Studio, assistentes de 3 e 4 passos, Estação de Trabalho, kit do Veo 3, menu Ferramentas). |
| 10 | "Onde as mídias ficam salvas?" → decisão: **mídia no repositório, sem upload** | **v7**: `public/media/<categoria>/<nome>`, plugin do Vite que lê a pasta, **Mapa de mídia**, avatares descobertos por arquivo, produtos por id. *Esta etapa foi feita numa sessão intermediária; a descrição aqui foi reconstruída lendo o código.* |
| 11 | "Cartões de cena são todos vídeo MP4 e o meu vídeo não aparece" | **v8**: imagem **ou** vídeo em qualquer card, vídeo toca sozinho nos cartões de seleção, aviso quando o codec não toca, quadro do vídeo como referência para a IA. Bug achado: botão de clique com fundo cinza tampando a mídia. |
| 12 | Replicar um site que "tira a cara de IA" a partir de uma captura de tela | **v9**: **Humanizar IA** (rota `#/humano`, logo abaixo de Trendly): modo Imagem/Vídeo, comparação Original × Realista, presets, comandos, prompt otimizado. Textos escritos por nós. |
| 13 | Usar a API da Kalodata no card "Produtos mais vendidos" e no "Selecione o Produto Viral", de graça | **Em aberto.** Veja a seção 20. |
| 14 | Este arquivo | `HISTORICO-DO-PROJETO.md` + `testes-e2e.zip`. |
| 15 | Melhorar **"Prompts dos Vídeos do TikTok"** seguindo um briefing (o produto do vídeo idêntico à foto; a imagem é subida no Flow e isso entra nas Observações) | **v10**: os 48 cards reescritos no formato novo (Prompt B), com Observações do Flow, **Prompt A** (foto da cena) e **Prompt C** (ações extras) em cada card, guia no topo e **"Gerar com a minha foto"** (Gemini, foto obrigatória, conferência da narração). Detalhes na seção 9.1. |
| 17 | **"Eu não entendi esses prompts. É para criar o vídeo?"** e **"o layout está muito grudado e centralizado; tem que ocupar por completo, em todas as páginas"** (print de 2500 px de largura; colou o texto do "Prompt C") | **v11**: cards de vídeo compactos com **"O que acontece no vídeo" em português**; **área de montagem** com campos em português e o prompt final se completando sozinho (sem colchetes soltos); clipes extras como prompts completos; guia em linguagem simples; **layout largo em todas as páginas**; capa do Reels Studio sem título duplicado. Detalhes na seção 9.2. |
| 18 | Print da área de montagem: **"achei que a IA ia gerar o prompt, mas ela só copia o que eu passei"**; o usuário colou a **ficha técnica inteira** (e o título da loja) nos campos, e o prompt saiu com 50 linhas de especificações no lugar da narração. Disse que o **gerador "com a minha foto" (diálogo) ficou bom** | **v12**: **Passo 1 "a IA preenche para você"** dentro da área de montagem (foto + título + descrição → narração curta, tamanho das medidas, o que a foto mostra, quem aparece e **ação adaptada ao produto**, com avisos); **proteção contra ficha técnica** (narração longa demais não entra no prompt; aviso no campo "o que aparece"); gramática das ações com `[REAL USE]`. Detalhes na seção 9.3. |
| 19 | Print dos **Clipes extras** sem narração: **"isso seria um vídeo, né? Porém está sem narração"** | **v13**: cada clipe extra pode levar a **sua própria fala** (padrão), continuando a história, com o **mesmo perfil de voz** repetido igual e a chamada para ação só no último; opção **Sem fala** (comportamento do briefing); **Roteiro completo da sequência**; a IA escreve as falas (`narration2`, `narration3`); o gerador completo (diálogo) ganhou a mesma opção. Detalhes na seção 9.4. |
| 20 | **Nova aba "Manequins"** abaixo de Humanizar IA com os 10 prompts de um documento (vestido em manequim: 5 de frente e 5 de costas, fala em espaço separado) e "esse aqui também para trocar a roupa… coloque no manequim". **Só um documento chegou** (o dos 10 vídeos) | **v14**: aba **Manequins** (`#/manequins`): os 10 vídeos no modelo do documento; **trocar a roupa** = escolher o tipo de peça (8) e os prompts adaptam o vocabulário; **prompts de imagem** (frente e costas) para vestir o manequim com a peça; fala em caixa separada com contador, que entra no fim do prompt (opcional); **IA escreve as 10 falas**. Detalhes na seção 11.1. |
| 22 | **"Mova Prompts dos Vídeos do TikTok, Prompts Prontas e Movimentos Especiais do painel para a Galeria de Prompts, na categoria de prompts prontos, e verifique o que mais dá para ajustar"** | **v16**: seção **"Prompts prontos"** na Galeria (3 coleções, 7 pastas, 79 cards) com todas as funções preservadas; 3 cards saem do painel; links antigos redirecionam; **auditoria**: CSS morto, texto do Radar, **acessibilidade (120 → 0 violações)**, títulos de aba, Dependabot mensal, código sem uso. Detalhes na seção 11.3. |
| 21 | **"Reestruture a Galeria de Prompts: tire do Trendly e coloque abaixo de Manequins; opção de editar o prompt (um lápis ao lado do copiar); subir novos vídeos no media, igual ao print"** (print de uma galeria de vídeos com filtros à esquerda, grade de cards e janela de detalhes com o prompt) | **v15**: **Galeria de Prompts** virou aba própria (`#/galeria`, abaixo de Manequins; a rota antiga redireciona); layout com filtros à esquerda, grade e janela de detalhes; **lápis para editar** no card e ao lado de "Copiar prompt inteiro"; **vídeos novos pela pasta `public/media/gallery` viram cards sozinhos**. Detalhes na seção 11.2. |

### Material de referência que o usuário forneceu (vídeos e capturas)
- **Painel "TikTok Shop Creator"** (3 vídeos): painel de ferramentas, Análise de Produto, Autoanálise de Vídeo (até 100 MB), Gerador de Headlines, "Prompts Prontas" (7 pastas), "Movimentos Especiais".
- **Vídeo do Trendly** (10:03 de duração; é sempre o mesmo arquivo, mesmo hash):
  - **0:00–3:47:** os fluxos UGC (4 passos), POV (3 passos) e Provador, mais as telas de resultado.
  - **~6:33:** galeria de avatares. **~7:23–8:04:** Galeria de Prompts. **~8:30 em diante:** Hacks (Cartomante, Religioso, Frutas Falantes).
- **Capturas de tela:** escolha de estilo (UGC, POV, Provador), passo "Roteiro & Voz", "Configuração da Cena", e o site de realismo (base do Humanizar IA).
- **Página de preços da Kalodata** (créditos por chamada): seção 20.

---

## 4. Stack e comandos

- **React 18**, **TypeScript 5**, **Vite 5**, **react-router-dom 7** (`HashRouter`), **lucide-react** (ícones), **vitest 2**.
- Node **22** (`.nvmrc`); `engines: node >=20`. Fontes: Inter e Sora (Google Fonts).
- **Sem backend.** Tudo roda no navegador. As únicas chamadas externas são ao Gemini (`generativelanguage.googleapis.com`).
- Roteamento por `#` e `base: "./"`: funciona em `usuario.github.io/repo/` sem configuração extra e sem 404 ao dar F5.

| Comando | O que faz |
| --- | --- |
| `npm install` / `npm ci` | Instala dependências |
| `npm run dev` | Servidor de desenvolvimento (porta 5173; a mídia nova aparece na hora) |
| `npm run build` | Checa tipos e gera `dist/` |
| `npm run preview` | Serve o `dist/` |
| `npm run typecheck` / `npm test` | Tipos / testes unitários |
| `npm run ci` | Tipos + testes + build (o mesmo do pipeline) |
| `npm run clean:stale` | Remove arquivos de versões antigas que sobraram na pasta |

`predev` e `prebuild` rodam `scripts/check-stale.mjs`, que **avisa** se existirem arquivos de versões antigas: `src/App.jsx`, `src/App.tsx` (hoje é `Root.tsx`), `src/main.jsx`, `src/data.js`, `src/styles.css` ou `vite.config.js`. `npm run clean:stale` apaga esses arquivos. Os scripts `dev`/`build` passam `--config vite.config.ts` de propósito, para que um `vite.config.js` antigo não ganhe prioridade.

---

## 5. Estrutura de pastas

```text
prompt-para-video/
├─ index.html                 CSP (política de segurança) e fontes
├─ vite.config.ts             plugin da mídia, base "./", vitest
├─ package.json  .nvmrc  tsconfig.json  README.md
├─ .github/
│  ├─ workflows/ci.yml        valida PRs e branches (tipos, testes, build)
│  ├─ workflows/deploy.yml    na main: valida e publica no GitHub Pages
│  └─ dependabot.yml          (semanal; veja pendências)
├─ scripts/
│  ├─ media-scan.ts           lê public/media e monta a lista de arquivos
│  ├─ media-plugin.ts         plugin do Vite (módulo virtual "virtual:media-manifest")
│  ├─ check-stale.mjs / stale-lib.mjs   aviso e limpeza de arquivos antigos
│  └─ *.test.ts
├─ public/media/<categoria>/  imagens e vídeos de prévia (veja seção 12)
└─ src/
   ├─ main.tsx  Root.tsx      entrada e rotas (lazy loading por página)
   ├─ pages/                  Dashboard, ToolPage, SettingsPage, Welcome, SoonPage, NotFound (as bibliotecas estão em src/galeria/)
   ├─ components/             Shell, Sidebar, Modal, ConnectPanel, MediaView, MediaSlot, ResultView, ...
   ├─ context/                GeminiContext (chave, modelos, fallback), ToastContext
   ├─ hooks/                  useGenerate, useHistory, useLibrary, usePersistentState, useFavorites, useInView
   ├─ lib/
   │  ├─ gemini/              cliente da API (client, models, files, image, errors, json, http, types)
   │  ├─ media.ts  mediaResolver.ts  mediaSlots.ts  slug.ts   mídia por pasta
   │  └─ storage.ts keyStore.ts usage.ts clipboard.ts
   ├─ tools/                  definições das 9 ferramentas de IA, prompts de sistema, esquema de saída
   ├─ data/                   catalog.ts (painel), bibliotecas (Prontas, Movimentos, Vídeos)
   ├─ trendly/                aba Trendly (layout, pages, components, data, lib, hooks, css)
   ├─ humano/                 Humanizar IA (page, components, data, lib, css)
   └─ styles/app.css          tema escuro com destaque rosa
```

---

## 6. Rotas e telas

| Rota (com `#`) | Tela |
| --- | --- |
| `#/` | Painel de ferramentas (15 cards, busca, favoritos com estrela) |
| `#/ferramenta/:id` | Ferramenta de IA (pov, ugc, influencer, copy, headlines, defesa, crescimento, analise-produto, analise-video) |
| `#/biblioteca/:id` | **Redireciona** para `#/galeria?c=<coleção>` (e `&pasta=<pasta>` se vier `?cat=`). As coleções `prontas`, `movimentos` e `videos` moram na Galeria |
| `#/em-breve/:id` | Telas "Em breve" (`mais-vendidos`, `aluno`, `radar`) |
| `#/configuracoes` | Perfil, chave e modelo do Gemini, apagar dados |
| `#/humano` | Humanizar IA |
| `#/manequins` | Manequins (10 vídeos de roupa em manequim e o prompt para vestir o manequim) |
| `#/trendly` | Redireciona para `#/trendly/reels` |
| `#/trendly/reels` e `/reels/:style` | Escolha do estilo e assistente (`ugc`, `pov`, `provador`) |
| `#/galeria` | **Galeria de Prompts** (aba própria, abaixo de Manequins). `#/trendly/galeria` redireciona para cá |
| `#/trendly/influencer` | Influencer Studio (avatares) |
| `#/trendly/hacks` e `/hacks/:id` | Hacks (`cartomante`, `religioso`, `frutas`) |
| `#/trendly/produtos` | Lista de produtos (alimenta "Selecione o Produto Viral") |
| `#/trendly/agente` | Agente IA (chat) |
| `#/trendly/midia` | **Mapa de mídia** (nome certo de cada arquivo e o que já foi encontrado) |
| `#/trendly/criar/:style`, `#/trendly/avatares` | Redirecionamentos de rotas antigas |

**Barra lateral:** Painel, Trendly, **Humanizar IA** (logo abaixo de Trendly), **Manequins** (logo abaixo de Humanizar IA), **Galeria de Prompts** (logo abaixo de Manequins), Configurações; mostra se o Gemini está conectado e quantas chamadas foram feitas hoje (contador local deste navegador).

**Entrada:** se não houver chave e o usuário não tiver escolhido "Explorar sem conectar", aparece a tela de boas-vindas com o passo a passo para colar a chave.

---

## 7. Integração com o Gemini

- **Chave:** colada pelo usuário (começa com `AIza`). É **validada listando os modelos** da conta. Fica em `localStorage` (`ppv:gemini-key`) ou em `sessionStorage` se "Lembrar neste dispositivo" estiver desmarcado. **Nunca vai para servidor nosso.**
- **Modelos:** o app **não fixa modelo**. Lista os modelos da chave (filtra imagem, áudio, embeddings, Gemma etc.), ordena por preferência (`PREFERRED_MODELS`: 3.6-flash, 3.5-flash, 3.1-flash-lite, 3-flash-preview, 2.5-flash, 2.5-flash-lite) e, se um falhar por cota ou indisponibilidade, **passa ao próximo** (fallback). Em Configurações dá para fixar um modelo.
- **Resiliência:** retentativa em 429 se o `retryDelay` for ≤ 20 s; backoff em 5xx; timeout de 120 s; cancelamento; mensagens de erro em português (`errors.ts`).
- **Saída estruturada:** o Gemini responde em JSON validado por `responseSchema` (`tools/schema.ts`: `summary` + `sections[]` com `items[]`); `normalizeOutput` protege contra desvios; `parseModelJson` tolera cercas de markdown.
- **Imagens:** reduzidas no navegador (máx. 1536 px, JPEG) antes de enviar.
- **Vídeo (Autoanálise):** envio pela **File API** (upload resumável), espera o processamento, e **apaga o arquivo** ao terminar. Limite do app: 100 MB.
- **Referência visual a partir da pasta de mídia:** `trendly/lib/mediaPart.ts` converte a imagem do avatar/produto em parte do pedido; se só existir vídeo, usa a **imagem de capa** (`.jpg` de mesmo nome) ou captura **um quadro do vídeo**.
- **Aviso:** os modelos do Gemini mudam com frequência (uma fonte indicou desligamento dos 2.5 em 16/10/2026). Por isso a lista vem da API.

---

## 8. Ferramentas de IA do painel (`src/tools/definitions.ts`)

Todas usam o mesmo formulário/resultado (`ToolPage`), com prompts de sistema em `tools/knowledge.ts`
(regras gerais, padrões de bom prompt de produto, nota de política).

| Ferramenta | Entrada | Saída |
| --- | --- | --- |
| POV | até 5 imagens do produto, categoria, modo (Frames/Elementos), cenário, ideia, fala | 3 conceitos com prompts (imagem inicial/final e movimento, ou um prompt de vídeo) |
| UGC | imagens, formato, duração | 3 conceitos: gancho, prompt de vídeo, fala, observações |
| Gerador de Influencer Realista | descrição da pessoa **fictícia**, ambiente | prompt de identidade, variações, vídeo curto, regras de consistência |
| Gerador de Copy | imagens, produto, detalhes | títulos, descrições, falas, hashtags |
| Gerador de Headlines | imagens, dor/público | exatamente 10 headlines dor + solução, "anti-violação" |
| Defesa de Violações | tipo, notificação, **fatos reais** | defesa curta/completa/em inglês + provas a anexar (usa só fatos informados) |
| Crescimento de Contas | nicho, fase | diagnóstico, plano de 7 dias, prompts, métricas |
| Análise de Produto | imagens | público, dores, ângulos, copy, riscos de violação |
| Autoanálise de Vídeo | vídeo até 100 MB | nota, pontos fortes, melhorias, gancho, risco de violação, potencial |

Resultado: copiar por item/seção/tudo, baixar `.txt`, "gerar de novo", **histórico** (10 por ferramenta, no navegador).

---

## 9. Bibliotecas de prompts (hoje dentro da Galeria de Prompts; veja a seção 11.3)

- **Prompts dos Vídeos do TikTok** (`data/videoSpecs.ts` + `data/videoPrompts.ts`): 48 cards no **formato novo** (veja a seção 9.1). Antes eram prompts com microcenas, reconstruídos de trechos de vídeo.
- **Prompts Prontas** (`data/promptsProntas.ts`): 7 pastas (Ganchos Especiais, Maquiagem/Skincare/acessórios, Relógios, Roupas Masculinas, Roupas Femininas, Calçados Masculinos, Calçados Femininos). Textos de partida, marcados "rascunho".
- **Movimentos Especiais** (`data/movimentos.ts`): 7 movimentos.
- Em todas: busca, favoritos, **editar** (as edições ficam no navegador), "Novo prompt", "Restaurar original", **"Adaptar com IA"** (reescreve o prompt para o produto do usuário via Gemini).
- Mídia de prévia: pasta `library/` (nome do card ou id).

### 9.1 Prompts dos Vídeos: formato novo (etapa 15)

**Origem:** um briefing do usuário ("Gerador de prompts de vídeo (Veo) com produto idêntico à foto"). Ele explica por que o formato antigo falhava (texto genérico divergia da imagem, microcenas com ângulos diferentes forçavam o Veo a inventar lados, interação sem trava de integridade, e a foto não era o primeiro quadro) e define o formato novo.

**Mapa do que existia:** os cards 0 a 19 eram prompts de vídeo com microcenas (o formato que falha); os cards 20 a 47 eram **prompts de imagem** com o comando de movimento nas Observações. No formato novo, o prompt de imagem vira o **Prompt A** (foto da cena) e o movimento vira a **ação do Prompt B**.

**O que cada card tem agora:** Prompt B (campo principal), Observações (a foto vai no Flow em **"Frames to Video"**, como primeiro quadro, mais os 5 passos e o aviso do card), e blocos recolhidos **Prompt A** e **Prompt C**. O botão virou **"Gerar com minha foto"**.

**Regras** (resumo; o texto completo está em `src/lib/veo/briefing.ts`): foto real = primeiro quadro; **[VISUAL LOCK]** só com o visível; **[SCALE LOCK]** (proporção visível ou medidas reais, nunca estimar); **[SUBJECT LOCK]**; um plano contínuo, câmera travada, sem girar nem mostrar lados que a foto não mostra; cláusula de integridade; ação em 2 ou 3 fases; zero texto/logo/ícone/overlay; microcenas na edição (CapCut), 2 a 4 clipes de plano único; narração só com a descrição do produto, 8 s = 22 a 26 palavras e 4 a 6 s = 12 a 18, sem as palavras proibidas.

**Código:**
- `src/lib/veo/briefing.ts`: **fonte única** das regras. `buildPromptA/B/C`, `buildObs`, `voiceProfile`, contagem e checagem da narração, `VEO_SYSTEM` (o briefing como prompt de sistema do Gemini) e `veoUserPrompt`.
- `src/data/videoSpecs.ts`: os 48 cards (cenário, quem aparece, ação, variações, integridade, voz, aviso). `src/data/videoPrompts.ts` monta os cards a partir deles. **Títulos, ordem e ids (`video-0` a `video-47`) não mudaram**, para as mídias de `public/media/library/` continuarem valendo.
- `src/components/VideoGuide.tsx` (guia + checklist no topo), `VeoDialog.tsx` (gerador com a foto; **sem foto o botão fica desativado**; o app confere as palavras da narração), `PromptCard.tsx` (blocos A e C), `LibraryPage.tsx`. `LibraryItem` ganhou `spec` e `extras`.
- Saída do gerador, em seções: "O que vi na foto", "Prompt A (foto da cena)", "Prompt B (vídeo)", "Narração", "Clipes extras (Prompt C)", "Alertas", "Lembrete".

**Adaptações de segurança e coerência** (decisões minhas, para respeitar o formato): "Queimando com o Isqueiro" **sem chama** (isqueiro apagado); "Jogando tinta" **não muda a cor da peça dentro do clipe** (a troca é na edição); "Calça no apoio girando" gira só alguns graus; cards que antes tinham o produto "falando" ou várias cenas passaram a ter voz fora de cena e plano único; vozes masculinas só onde a pessoa é homem (5 cards).

**Se o usuário já tinha editado um card** (edições ficam no navegador): a edição antiga continua valendo; "Restaurar original" mostra o formato novo. Não houve migração para não apagar nada do usuário.

**O que NÃO foi verificado:** nenhum prompt foi rodado no **Veo** de verdade (não dá para saber se o produto sai idêntico); o gerador nunca falou com uma chave real do Gemini (só resposta simulada, nas capturas usei o exemplo do arranhador do briefing).

### 9.2 Reformulação de clareza e layout (etapa 17)

**O problema:** o usuário não entendia os prompts. Os cards mostravam um texto em inglês com `[VISUAL LOCK: ...]` no meio (campos que ele teria de editar dentro do texto) e o "Prompt C" era uma instrução misturada com prompt (com um defeito real: faltava o ponto antes de "The product stays rigid…"). E o layout estava estreito e centralizado em telas largas.

**O que mudou (substitui a interface descrita na 9.1):**
- **Card compacto** (`VideoCard`): capa, quem aparece, tipo de voz e **"O que acontece no vídeo"** em português (campo `resumo` de cada card em `videoSpecs.ts`), e os botões **Montar prompt** e **Preencher com IA**. Sem caixas de texto no card.
- **Área de montagem** (`VideoWorkspace`, em `Modal full`, quase tela cheia): à esquerda a explicação, os 3 passos (Flow > "Frames to Video") e os campos em português (o que a foto mostra, tamanho, quem aparece, uso real quando o card pede, narração com contador); à direita as abas **Prompt do vídeo**, **Clipes extras** (prompts completos, cada um com uma frase em português: `variantsPt`) e **Foto da cena**. O que falta fica destacado em amarelo; quando completa, vira verde. Campos salvos por card (`veoform:<id>`).
- **`briefing.ts`:** `PromptFill`, `buildPromptB(spec, fill, seconds)`, `buildClip` (substitui `buildPromptC` e o `buildClipPrompts` que existia numa correção parcial), `buildPromptA(spec, fill)`, `missingParts`, `needsRealUse`/`applyRealUse`, `SUBJECT_FIELD`. As frases do usuário entram com a primeira letra maiúscula e ponto final.
- Os cards de vídeo **não têm mais `extras`** nem texto editável (a edição é pelos campos).
- **Guia** reescrito em linguagem simples (4 passos lado a lado + glossário "Entenda os termos").
- **Layout:** `.page`, `.tl`, `.tw`, `.hm`, `.tl-styles` e os modais de trabalho deixaram de ter largura máxima; as grades (`.pgrid`, `.vgrid`, `.tgrid`, avatares, produtos, movimentos, galeria) usam `repeat(auto-fill, minmax(min(100%, N px), 1fr))`; `AutoTextarea` faz as caixas das bibliotecas crescerem sem rolagem; Configurações em grade de 2 colunas; `TrendlyMedia` ganhou `hideCaptionWhenMedia` (capas do Reels Studio com título embutido não repetem o texto).
- **Testes:** `briefing.test.ts` reescrito (106 testes no total); `e2e_veo.py` e o novo `e2e_layout.py` rodam em **2500 × 1260** (a tela do usuário) e em 1366 × 900, em 17 rotas.
- Os testes antigos `e2e.py` e `e2e_media3.py` procuravam `.pcard` na página de vídeos; passaram a procurar `.vcard`.

**Não verificado:** como o Veo trata um prompt em inglês com trechos em português nos campos; o texto de ajuda não afirma mais que "inglês funciona melhor" (isso não foi confirmado).

### 9.3 A IA preenche os campos da área de montagem (etapa 18)

**O problema:** a área de montagem da 9.2 só tinha campos manuais. O usuário colou a descrição inteira em campos que não eram para isso e o app copiou tudo para dentro do prompt, sem filtrar e sem criar a narração. Ele esperava que a IA gerasse o prompt a partir do produto e da descrição.

**O que mudou:**
- **Passo 1 (IA)** em `VideoWorkspace.tsx`: foto (opcional, recomendada), título, descrição/ficha técnica, medidas. O botão **Preencher tudo com IA** chama o Gemini com `FILL_SYSTEM` e `fillUserPrompt` (`briefing.ts`) e aplica a resposta lida por `parseFill`. Os itens da seção "Campos" (rótulos `visual`, `scale`, `subject`, `action`, `actionPt`, `clip2`, `clip2Pt`, `clip3`, `clip3Pt`, `narration`) preenchem os campos; o que a IA omite fica como estava; a seção "Alertas" vira os "Avisos da IA". Sem foto, a IA **omite** `visual` e `subject` (o briefing manda descrever só o que a foto mostra) e avisa.
- **Ação adaptada:** se a ação do card não combina com o produto (o usuário usou o card de eletrodoméstico para uma cômoda), a IA troca por um gesto de uso real (`actionEn`/`actionPt`, `clipsEn`/`clipsPt` no estado `veoform:<id>`); aparece o selo "Adaptado ao seu produto pela IA" e o botão "Voltar à ação do card".
- **Proteção contra ficha técnica:** `cleanNarration` (uma linha, sem aspas internas) e `narrationTooLong` (mais de limite + 10 palavras): a narração longa **não entra** no prompt (volta o modelo destacado) e o contador explica. O campo "o que aparece na foto" avisa quando tem peso/medidas ou mais de 350 caracteres. O texto do usuário nesse campo **não é descartado** (só avisado).
- As 7 ações com `[REAL USE]`/`[REAL TEST]` passaram a ler bem com um trecho inserido (`...performs this real use: <texto>`), o que acabou com frases como "does abri as portas".
- Botões: card e guia agora dizem **Gerar com IA** (abrem o gerador completo em diálogo, que o usuário aprovou); a área de montagem tem a IA embutida (a antiga ligação para o diálogo foi removida de lá).
- Testes: 115 unitários (limpeza da narração, ficha técnica não vaza, `parseFill`, `FILL_SYSTEM`, `fillUserPrompt`, gramática das 7 ações); `e2e_veo.py` cobre a IA com foto, sem foto, a ficha técnica nos campos errados, a persistência e o botão "Voltar à ação do card".

**Não verificado:** a IA de verdade (todos os testes e as capturas usam resposta simulada do Gemini); se o Veo respeita a ação adaptada e a trava de sujeito; como o Veo trata campos do usuário em português dentro do prompt em inglês.

### 9.4 Clipes extras com fala (etapa 19)

**O problema:** o briefing original (seção "Prompt C") manda **apagar a linha "Voice"** dos clipes extras e colocar a narração na edição. Aplicado ao pé da letra, os clipes extras saíam **mudos**. Mas o usuário vê cada clipe extra como um vídeo de 8 s completo, parte de uma sequência (clipe 1, 2, 3), e esperava narração em todos. **Decisão:** oferecer as duas formas, com **fala por clipe como padrão**, porque o próprio briefing já prevê vários clipes com voz ("repita o PERFIL DE VOZ completo, palavra por palavra, em cada prompt").

**O que mudou:**
- `buildClip(spec, i, fill, voice?)`: com `voice`, o clipe leva a linha "Voice" com o **mesmo perfil de voz** do clipe 1 (a mesma função `voiceProfile`) e a sua fala; sem a fala, aparece o modelo destacável "a new line for clip N that continues the story without repeating the previous clips". Sem `voice`, o clipe sai sem voz, como antes. Falas longas demais (ficha técnica) não entram (mesma regra do clipe 1).
- **Área de montagem, aba Clipes extras:** escolha "Cada clipe com a sua fala" / "Sem fala" (`clipVoice`), uma caixa de fala por clipe (`clipNarr`, com contador), aviso "Falta a fala de N clipes" e o bloco **"Roteiro completo da sequência"** (todas as falas em ordem, total de palavras, botão de copiar).
- **IA do Passo 1:** novos rótulos `narration2` e `narration3` em `parseFill`/`FILL_SYSTEM`; o pedido (`fillUserPrompt`) informa a sequência ("1 clipe principal + N clipes extras COM fala"): a `narration` vira a abertura sem chamada para ação, e a chamada para o carrinho vai só na última fala. Com "Sem fala", o pedido diz "Sem clipes extras com fala: a fala principal fecha com a chamada para ação". "Voltar à ação do card" também limpa as falas.
- **Gerador completo (diálogo "Gerar com IA"):** opção "Cada clipe extra com a sua fala" (ligada por padrão; some quando os clipes extras são 0); `VeoRequest.extraVoice`; o sistema (`VEO_SYSTEM`) explica as duas formas; a seção "Narração" lista uma fala por clipe ("Clipe 1", "Clipe 2"…) e o app confere **cada** fala (`findNarrations`).
- Testes: 124 unitários; `e2e_veo.py` cobre o padrão com fala, o perfil de voz idêntico, o roteiro completo, "Sem fala", a ficha técnica na fala do clipe, a IA escrevendo as falas e o diálogo com uma conferência por fala.

**Não verificado:** como o Veo trata a mesma voz em vários clipes gerados separadamente (o texto da tela avisa que a voz pode variar); se o perfil de voz repetido igual realmente mantém a voz parecida. A opção "Sem fala" existe justamente para quem preferir narrar tudo de uma vez na edição.

---

## 10. Trendly (`src/trendly/`)

**Layout (`TrendlyLayout.tsx`):** navegação própria no topo: **Produtos**, **Ferramentas ▾** (Reels Studio, Agente IA, Influencer Studio, Hacks Virais; a Galeria de Prompts saiu deste menu na etapa 21) e botão **Mídia**. Visual preto com destaque rosa (`trendly.css`).

### 10.1 Reels Studio: os três fluxos (`lib/flow.ts`, `pages/WizardPage.tsx`)

| Estilo | Passos | Resultado |
| --- | --- | --- |
| **UGC** (4) | Avatar/Influencer → Produto → Configuração da Cena → Roteiro & Voz | **"Direção de IA Pronta!"** |
| **POV** (3) | Produto → Configuração Visual → Roteiro & Voz | **"Direção de IA Pronta!"** |
| **Provador** (4) | Avatar → Produto → Configuração da Cena → Prompt de Movimento (a 4ª barra continua apagada) | **"Seu Sistema de Criação Está Pronto"** |

Detalhes por passo:
- **Avatar:** abas Mulheres / Homens / Meus Avatares. 12 avatares-base **fictícios, sem foto**: Carolina, Daniela, Ana, Fernanda, Carla, Juliana, Laura, Maria (mulheres); Fábio, Marcos, Juliano, Miguel (homens). A foto vem do arquivo (`avatars/carolina`); avatares próprios por arquivo `f-nome`/`m-nome`.
- **Produto ("Selecione o Produto Viral"):** usar o **próprio produto** (upload de até 3 fotos; servem só para a IA e **não são salvas**) ou escolher da lista de **Produtos** (faixas "#1/#2/#3 VIRAL", "Em Alta", "Alta Demanda"; os 12 itens de exemplo são **marcados "exemplo"** e não são dados reais).
- **Cena (UGC/Provador):** 10 cenários, 2 interações (Câmera Frontal, No Espelho), 3 poses (corpo inteiro, cintura para cima, sentado; a 3ª é interpretação minha).
- **Configuração Visual (POV):** 6 cenários, 4 aparências de mãos (luvas brancas, masculina, feminina, sem mãos), 5 estilos de apresentação, duração **8 s a 40 s (1 a 5 takes)**.
- **Roteiro & Voz:** voz Feminino/Masculino, 6 tonalidades, **takes de 8 s com 20 a 25 palavras** e contador por take. **"Criar roteiro"** abre um modal com um prompt pronto para colar no ChatGPT ou no Gemini; **"Preencher automático"** usa o Gemini. UGC tem 2 takes; POV tem 1 a 5.
- **Movimento (Provador):** grade com os **vídeos da galeria** (autoplay), escolher um.

Resultados:
- **Direção de IA Pronta!** (`DirectionResult`): imagens de referência clicáveis (baixam o arquivo); **Estação de Trabalho** com 3 itens (salvar referências, roteiro de direção do Veo 3 com "Ver Prompt" e "Copiar Take n", "Gerar com IA de vídeo": Grok, YouTube/Dream Screen, Flow, Google Opal); botão **"Gerar Prompt de Imagem"** (primeiro frame, sob demanda); **"Começar Novo Projeto"**. Com 1 take aparece "Roteiro neural sincronizado" e "Copiar Roteiro Oficial". O link do Flow é `labs.google/fx/tools/flow`.
- **Sistema de Criação** (`KitResult`): referências de avatar e produto, **Passo 1 · Imagem** (prompt do frame) e **Passo 2 · Vídeo** (anima o frame), "Abrir Veo 3", "Refazer".
- A fala de cada take vai ao Gemini **exatamente como o usuário escreveu**.
- Tela de espera com mensagens ("Lendo seu roteiro…", "Escolhendo o melhor cenário…").
- Sem Gemini conectado, os passos funcionam; ao gerar, abre a conexão.

### 10.2 Outras telas
- **Galeria de Prompts** (dados em `data/gallery.ts`; a **página** foi movida para a aba própria `#/galeria`, veja a seção 11.2): **46** prompts (12 imagem, 34 vídeo). Abas Todos/Imagens/Vídeos/Favoritos, busca, "Carregar Mais Prompts" (12 por página), "Copiar Prompt", "Ver prompt", "Como usar?". **Os títulos vieram da gravação (OCR); os textos dos prompts foram escritos por nós.** Vídeos são mudos (`Audio: none`) e todos trazem as restrições (sem texto, legenda, logo, marca d'água).
- **Hacks** (`data/hacks.ts`): Cartomante, Religioso, Frutas Falantes. "Criador de Vídeo Viral": escolher personagem (avatar, ou uma das 10 frutas + personalidade) → o Gemini escreve 4 roteiros → escolher ou escrever o seu → gera os prompts do vídeo. **Regras de conteúdo** (mostradas na tela e enviadas ao Gemini): rotular como conteúdo de IA; não usar imagem/voz de pessoa real; sem pedidos de seguir em troca de afeto e sem promessa de dinheiro/cura; Cartomante sem previsões sobre saúde, morte, gravidez, dinheiro; Religioso sem milagres prometidos nem pedido de doações; Frutas sem alegação de saúde.
- **Influencer Studio:** gerencia os avatares (por arquivo) e liga ao gerador "Influencer Realista".
- **Produtos:** lista editável no navegador (`trendly:products-v2`), **Importar lista** (uma linha por produto; `;alta` ou `;em-alta` opcional). Foto por arquivo `products/<id>`.
- **Agente IA:** chat simples com o Gemini, com contexto de TikTok Shop; aceita até 3 imagens; conversa salva no navegador. **É uma interpretação minha**: o vídeo de referência não mostrava essa tela.
- **Mapa de mídia:** veja a seção 12.

### 10.3 Prompts do Trendly (`trendly/lib/prompts.ts`)
`directionSystem` (UGC/POV), `frameSystem` (primeiro frame), `kitSystem` (Provador), `autoScriptSystem/User`, `scriptCopyPrompt`, `wizardUserPrompt`, e os de Hacks (`scriptsSystem`, `videoSystem`). Todos incluem `BASE_SYSTEM` + `PROMPT_CRAFT` (`tools/knowledge.ts`).

---

## 11. Humanizar IA (`src/humano/`, rota `#/humano`)

Replica o **conceito** de um site de "prompts de realismo" a partir de **uma captura de tela** (o site em si só carrega no navegador e não pôde ser lido). Chamado de "Humanizar IA" de propósito, para não usar o nome do site.

- **Imagem / Vídeo:** alterna o modo; cada modo tem os seus presets e comandos. Trocar de modo descarta presets do outro modo e mantém os comandos compatíveis.
- **Comparação Original × Realista** (`CompareSlider`): duas camadas (imagem ou vídeo); arrastar o divisor com o mouse ou usar teclado (`←` `→`, Shift para passos maiores, Home/End). Acessível (`role="slider"`).
- **Presets** (12): 6 de imagem e 6 de vídeo (inclui "[Vídeo] Vlog caseiro", "Vlog na rua", "Captura casual no bar"). Seleção múltipla, em carrossel.
- **Comandos** (34, em 7 categorias): Rosto e pele, Corpo, Dispositivo, Edição, Iluminação, Movimento (só vídeo), Outros.
- **Prompt otimizado:** `composePrompt` junta (1) o prompt original opcional, (2) as cenas dos presets na ordem escolhida e (3) os comandos na ordem das categorias; sem duplicar e com ponto final. **Limpar**, **Editar** (se mudar as seleções depois, aparece "Atualizar com as seleções" e o texto editado **não** é apagado), **Copiar**.
- Estado salvo em `humano:v1`. Aviso para **rotular como conteúdo de IA** ao publicar.
- **Imagens da comparação:** `public/media/humano/`: `padrao-imagem-original`/`-realista`, `padrao-video-original`/`-realista`, e opcionalmente `<preset>-original`/`-realista` e a miniatura `<preset>`. Sem arquivos, aparece um espaço reservado com o caminho esperado.
- **Não gera a imagem realista sozinho**: só monta o prompt (um modelo de imagem do Gemini não foi usado).

### 11.1 Manequins (etapa 20)

**Pedido:** uma aba abaixo de Humanizar IA com os 10 prompts de um documento (um vestido em manequim) e a possibilidade de trocar a roupa. **Só um documento chegou**; o "esse aqui também para trocar a roupa" foi interpretado como (1) escolher outra peça e (2) um prompt de imagem que veste o manequim com a peça. Se existir um segundo prompt do usuário, falta recebê-lo.

**O que foi feito** (`src/manequins/`):
- `data/videos.ts`: os 10 vídeos (5 de frente, 5 de costas) com os momentos e tempos do documento, título e explicação em português (com tokens do vocabulário da peça) e a fala original (vestido). `data/garments.ts`: 8 peças (vestido, saia, blusa, calça, short, conjunto, macacão, jaqueta) com vocabulário em inglês e em português, tons de manequim e cenário padrão.
- `lib/prompts.ts`: `buildVideoPrompt` (modelo do documento: `Create a realistic vertical 9:16 fashion boutique product video…`, `PRODUCT LOCK`, cenário, `ACTION` com tempos, `CAMERA`, `STYLE`, `NEGATIVE`, `AUDIO`), `buildImagePrompt` (frente e costas), `fillTokens`/`contract` (contração em português: "da saia", "do decote e do corpete"), `narrationFor`, e a IA das falas (`NARRATIONS_SYSTEM`, `narrationsUserPrompt`, `parseNarrations`).
- `pages/ManequinsPage.tsx`: guia em linguagem simples; Passo 1 (peça, manequim, mão, voz, cenário, descrição, "colocar a fala dentro do prompt", IA); Passo 2 (prompts de imagem); Passo 3 (abas De frente, De costas, Todos; cada vídeo com explicação, fala em caixa separada com contador, prompt completo, copiar prompt e copiar só a fala). Estado em `manequins:v1`.
- Reaproveita `PromptText` (agora em `components/PromptText.tsx`, compartilhado com a área de montagem dos vídeos), `AutoTextarea`, `CopyButton`, `useGenerate`, `cleanNarration`/`narrationTooLong`/`checkNarration`.
- **Falas do documento:** têm **14 a 18 palavras** (o documento promete 22 a 26) e **4 usam "sofisticado/a"** (a 10 também "impecável"). O app as mantém como vieram, mas os contadores e o aviso geral sinalizam; a IA das 10 falas corrige. Em outra peça que não o vestido, as falas começam vazias (elas falam de "vestido").
- **Defeito corrigido junto:** `checkNarration` não pegava "sofisticada" (feminino) nem plurais; as palavras proibidas agora são reconhecidas com flexão (`sofisticad[oa]s?`, `refinad[oa]s?`, `impec[aá]ve(l|is)`).
- Testes: 153 unitários (fidelidade ao documento, nenhum token sobrando em 8 peças × 10 vídeos × 2 manequins, "dress"/"skirt" não vazam na calça, contração, fala, IA); `e2e_manequins.py` (menu, layout largo, abas, copiar, editar fala, ficha técnica, troca de peça, manequim masculino, IA, persistência, celular).

**Não verificado:** nenhum prompt rodado no Veo (a peça sair idêntica, o manequim ficar parado, a voz falar a linha); o Passo 2 é meu e não estava no documento; a IA das falas só com resposta simulada. Não há mídia (capas) por vídeo nesta aba.

### 11.2 Galeria de Prompts como aba própria (etapa 21)

**Pedido:** tirar a galeria do Trendly e colocá-la abaixo de Manequins, com a opção de editar o prompt (lápis ao lado do copiar) e de subir novos vídeos pela pasta de mídia, no estilo de uma galeria de vídeos mostrada em um print (de **outro produto**: foi replicada a organização e a usabilidade, **não** o conteúdo, a marca nem os textos). Os 46 prompts e os textos continuam sendo os deste app.

**O que foi feito** (`src/galeria/`):
- **Mudança de lugar:** `Root.tsx` ganhou `galeria` (página nova) e a rota `trendly/galeria` virou `<Navigate to="/galeria" replace />`; a Galeria saiu do menu "Ferramentas" do Trendly (`TrendlyLayout.tsx`); Sidebar e card do painel (18 cards). A página antiga `trendly/pages/GalleryPage.tsx` foi removida. Os dados (`trendly/data/gallery.ts`) ficaram onde estavam (o Provador usa o passo "Movimento").
- `lib/galeria.ts`: `CATEGORIES` (9 categorias minhas; cada um dos 46 prompts em exatamente uma, `BY_CATEGORY`), `MEDIA_CATEGORY` ("Minha mídia"), `buildItems(mediaIds, kindOf)` (**um card automático por arquivo de `gallery/` que não é um dos 46**, em ordem alfabética e **antes** dos demais; id `media:<nome>`, título via `humanize`, prompt vazio), `applyEdits` ("editado" só se o texto difere do original; um prompt apagado de propósito vale), `filterItems`/`countItems`, `HOW_TO`.
- `components/GaleriaCard.tsx` (vídeo toca ao passar o mouse; coração; **copiar e lápis** ao passar o mouse, sempre visíveis em tela sem mouse), `GaleriaDetail.tsx` (`Modal gallery`: mídia à esquerda com setas e teclas ← →; à direita descrição, etiquetas, **"Copiar prompt inteiro" + lápis + Favoritar**, bloco PROMPT com Copiar e lápis próprios, editor com Título e Prompt (Salvar, Cancelar, Restaurar original), COMO USAR), `GaleriaFilters.tsx`.
- `pages/GaleriaPage.tsx`: lê os arquivos com `media.idsIn("gallery")`; edições em `galeria:edits`; favoritos reaproveitam `trendly:favorites`; pílulas Tudo/Vídeo/Imagem/Com mídia; busca (título, descrição e prompt); 60 por página + "Carregar mais"; botão "Como adicionar vídeos" (com o comando do `ffmpeg`); filtros recolhidos atrás do botão "Filtros" no celular.
- **Mapa de mídia:** arquivos novos de `gallery/` **não** são mais "nome errado"; o Mapa informa quantos viraram cards. Em outras pastas, o aviso de arquivo sem card continua.
- `Modal` ganhou `gallery`; `AutoTextarea` no editor (sem rolagem interna).
- Testes: 172 unitários (`galeria.test.ts`: categorias cobrem os 46, cards automáticos, edição, filtros, contagens); `e2e_galeria.py` (71 verificações em 2500 × 1260, com vídeos reais de exemplo na pasta: menu, rota antiga, layout, cards novos, vídeo que toca com o mouse, filtros, favoritos, copiar, lápis, detalhes e navegação, edição completa, card novo, Mapa de mídia, celular). Testes antigos ajustados: `e2e_trendly2.py` (menu com 4 itens), `e2e_media3.py` (galeria em `#/galeria`, o exemplo de "nome errado" foi para `avatars/`), contagens do painel (18) em `e2e.py`, `e2e_hm.py`, `e2e_manequins.py`, rota em `e2e_layout.py`.

**Não verificado:** os vídeos de exemplo dos testes e das capturas são barras de cor geradas pelo `ffmpeg`, não vídeos reais; as categorias e os textos dos 46 prompts são meus e nunca foram rodados no Veo; "Subir vídeos" continua sendo por commit no repositório (não há upload pelo site, por decisão antiga).

### 11.3 Prompts prontos dentro da Galeria e auditoria de qualidade (etapa 22)

**Pedido:** mover os três cards (Prompts dos Vídeos do TikTok, Prompts Prontas e Movimentos Especiais) do painel para a Galeria de Prompts, numa categoria de prompts prontos, e verificar o que mais dava para ajustar.

**Mover:**
- `lib/galeria.ts` ganhou `Collection`, `COLLECTIONS`, `READY_CATEGORY` ("Prompts prontos"), `libraryViews` (transforma os itens de cada `useLibrary` em cards da Galeria; ids `lib:<coleção>:<id>`; vídeos e movimentos são "vídeo", as prontas são "vídeo" se o texto fala em vídeo e senão "imagem"), `subtitleOf`, e os filtros `collection` e `folder`. `GaleriaItem` ganhou `origin`, `obs`, `userMade`, `cover`, `mode`, `draft`, `hasSpec` e `lib` (o item da biblioteca, para os diálogos).
- `GaleriaPage` usa os três `useLibrary` (as **mesmas chaves de antes**: `overrides:<coleção>`, `custom:<coleção>`) e os favoritos das duas listas (`trendly:favorites` para a galeria; `favorites` para os prompts prontos). Filtros iniciais vêm do endereço (`?c=` e `&pasta=`). Botão "Novo prompt" (cria em Prompts Prontas). O guia "Como funciona" aparece ao abrir a coleção dos vídeos.
- `GaleriaCard`: vídeos no formato novo têm **Montar prompt** e **Gerar com IA** no card; os demais, **copiar** e **lápis**; selos "Seu" e "Editado"; capa com emoji quando não há mídia. `GaleriaDetail`: vídeos no formato novo mostram "MODELO DO PROMPT" com os botões Montar prompt e Gerar com IA (sem lápis nem copiar, porque o texto final vem dos campos); os demais têm Copiar prompt inteiro + lápis + Adaptar com IA, o editor com **Prompt e Observações**, **Restaurar original**, bloco OBSERVAÇÕES e, nos prompts do usuário, título editável e **Excluir** (com confirmação). Montar prompt, Gerar com IA e Adaptar com IA fecham os detalhes e abrem o diálogo certo. `GaleriaFilters`: seção "Prompts prontos" (coleções e, na Prontas, as 7 pastas).
- `Root.tsx`: `biblioteca/:id` virou `LibraryRedirect`. `catalog.ts`: saíram os 3 cards (painel com 15). **Removidos:** `LibraryPage`, `PromptCard`, `VideoCard`, `MediaSlot` (o `SUBJECT_CHIP` foi para `data/subjectChip.ts`). `useLibrary.edit` aceita título só nos prompts do usuário.

**Auditoria ("o que mais dá para ajustar"):**
- **CSS morto:** um limpador removeu 132 seletores (13 KB) que usavam classes inexistentes; conferido contra o zip anterior que nenhuma classe em uso perdeu estilo. `.media-play` e `.media-fail` (que só carregavam com o CSS do Trendly) foram para o CSS global.
- **Texto do Radar** (`catalog.ts`): não afirma mais que a Kalodata é "paga e sem acesso aberto" (não verificado); fala da API cobrada por créditos. O texto de "Produtos mais vendidos" aponta para Trendly > Produtos.
- **Acessibilidade (axe-core):** 120 elementos com problema na primeira rodada, **0 depois das correções**: contraste do texto branco sobre rosa e laranja (cores sólidas `--pink-solid` `#e50076`, 4,57:1, e `--hm-accent-solid` `#de3500`, 4,55:1, só onde há texto branco; o botão principal usa um degradê mais fundo), nome acessível dos cards (`sr-only` "Abrir" + título e legenda visíveis, em vez de `aria-label`), ordem dos títulos (Galeria, Influencer Studio, "Em breve"; título principal nos assistentes do Trendly), ícones do Mapa de mídia com `role="img"`, texto pequeno `#8a8697`. Virou o teste permanente `e2e_a11y.py` (21 telas e 4 janelas).
- **Título da aba por tela** (`lib/pageTitle.ts` + `TitleSync`; 5 testes unitários) e verificação no navegador.
- **Dependabot mensal**, ignorando saltos de versão grandes (era semanal; antes eu só tinha recomendado).
- **Código sem uso removido:** `GALLERY_PAGE_SIZE` e `findNarration`.
- **Testes ajustados:** `e2e.py` (bibliotecas pela Galeria; painel com 15 cards), `e2e_media3.py` (prévias dos prompts prontos em `#/galeria?c=videos`), `e2e_veo.py` (entra pelos cards da Galeria; 99 verificações), `e2e_galeria.py` (127 prompts; 106 verificações, incluindo compatibilidade com edições e favoritos antigos, links antigos e Novo prompt), `e2e_trendly2.py` (`h2`), `e2e_layout.py`, `e2e_hm.py`, `e2e_manequins.py` (15 cards).

**Não verificado:** como o Veo trata os prompts (nada foi rodado nele); as categorias da Galeria e os textos dos prompts são meus; a classificação "vídeo ou imagem" das Prompts Prontas é por palavra no texto (7 de 24 falam em vídeo); a auditoria automática cobre as regras que o axe consegue medir, e **não substitui** testar com leitor de tela.

---

## 12. Sistema de mídia por pasta

**Regra de ouro:** não há upload no site. Os arquivos ficam em `public/media/<categoria>/<nome>.<ext>` e o app liga cada um ao card **pelo nome**. Como é uso pessoal, todo mundo que abre o site vê os mesmos arquivos.

| Pasta | Onde aparece | Nome do arquivo |
| --- | --- | --- |
| `styles` | Capas de UGC, POV, Provador | `ugc`, `pov`, `provador` |
| `gallery` | Galeria de Prompts e passo "Movimento" | o id do prompt: `giro-360`, `pacote-vid`, `cta-carrinho`… |
| `avatars` | Fotos dos avatares | o nome do avatar (`carolina`); avatar seu: `f-nome` ou `m-nome` |
| `products` | Foto de cada produto | o código do produto (aparece em Produtos) |
| `interactions`, `poses`, `hands` | Prévias do passo de cena e do POV | `frontal`, `espelho`, `corpo-inteiro`, `cintura`, `sentado`, `luvas`, `sem-maos`… |
| `hacks` | Exemplos dos Hacks | `frutas-ex1`, `cartomante-ex2`… |
| `library` | Prompts Prontas, Movimentos, Vídeos do TikTok | o título (`roupas-infantis`) ou o id (`video-0`) |
| `humano` | Humanizar IA | veja a seção 11 |

Regras e comportamento:
- Formatos aceitos: imagens `.jpg .jpeg .png .webp .avif .gif`; vídeos `.mp4 .webm .m4v`. Maiúsculas não importam. **`.mov` gera aviso** (quase nunca toca no navegador).
- **Imagem OU vídeo em qualquer card.** Se existirem os dois com o mesmo nome, o **vídeo toca** e a **imagem vira capa** (`poster`).
- **Nos cartões de seleção** (cena, pose, mãos, avatares, produtos, movimento, capas, hacks) o vídeo **toca sozinho**, mudo e em loop, **só enquanto está na tela** (`IntersectionObserver` em `useInView`). Na galeria, toca ao passar o mouse ou clicar. Com "reduzir movimento" ativo, mostra só o primeiro quadro (`#t=0.1` evita caixa preta).
- Se o vídeo falhar (codec, por exemplo HEVC de iPhone), o card mostra **"Este vídeo não toca no navegador. Converta para MP4 (H.264) ou WebM."**
- Os vídeos só começam a baixar quando o card chega perto da tela.
- **Peso:** o build **só avisa, não falha** (via `this.warn`): quando um arquivo passa de **95 MB** (o GitHub **bloqueia o push** acima de 100 MB) e quando a pasta passa de **900 MB** no total (o GitHub recomenda o repositório abaixo de 1 GB). Comando para comprimir: `ffmpeg -i entrada.mov -vf "scale=-2:720" -c:v libx264 -crf 28 -preset slow -movflags +faststart -an saida.mp4`.
- **Como funciona por dentro:** `scripts/media-scan.ts` lê a pasta; `scripts/media-plugin.ts` expõe o módulo virtual `virtual:media-manifest` (e observa a pasta em `npm run dev`); `src/lib/mediaResolver.ts` + `media.ts` resolvem `(categoria, nomes[])` para um item `{kind, url, poster}`; `src/lib/mediaSlots.ts` lista **todos os espaços possíveis** (alimenta o Mapa); as URLs recebem `?v=<hash>` para evitar cache velho.
- **Mapa de mídia (`#/trendly/midia`):** nome certo de cada card, ✔ nos já encontrados, "Copiar nome", filtro "só o que falta", e avisos de arquivo sem card (nome errado), formato não suportado ou grande demais. **Grupos completos aparecem recolhidos.**

---

## 13. Dados salvos no navegador

Tudo com o prefixo `ppv:` no `localStorage` (a chave do Gemini pode ir para `sessionStorage`). **IndexedDB não é mais usado** (era do upload, removido).

| Chave | Conteúdo |
| --- | --- |
| `gemini-key` | Chave do Gemini |
| `model`, `name`, `skipped` | Modelo escolhido, nome do perfil, "explorar sem conectar" |
| `favorites` | Estrelas do painel |
| `usage:<data>` | Chamadas feitas hoje (contador local) |
| `history:<ferramenta>` | Histórico de gerações (até 10) |
| `overrides:<coleção>`, `custom:<coleção>` | Edições e prompts novos das bibliotecas |
| `trendly:favorites`, `trendly:products-v2`, `trendly:agent` | Favoritos da galeria, lista de produtos, conversa do Agente |
| `humano:v1` | Seleções do Humanizar IA |

"Configurações > Apagar todos os dados" limpa tudo isso.

---

## 14. CI/CD e publicação (GitHub Pages)

- `ci.yml`: em PRs e em pushes fora da `main`: `npm ci` → tipos → testes → build.
- `deploy.yml`: em push na `main` (ou manual): as mesmas validações e, **só se passarem**, publica no Pages (`configure-pages@v5`, `upload-pages-artifact@v3`, `deploy-pages@v4`; `checkout@v4`, `setup-node@v4`; Node via `.nvmrc`).
- **Passo único no GitHub:** *Settings > Pages > Source: GitHub Actions*. Sem isso o primeiro deploy falha.
- Site final: `https://USUARIO.github.io/REPO/`. Repositório **privado** com Pages exige plano pago (pelo que li; confirme).
- `dependabot.yml` está **semanal**. Foi recomendado trocar para **mensal e ignorar saltos de versão grandes** (YAML pronto na conversa), mas **não foi aplicado**. PRs do Dependabot são opcionais; o PR com CI verde é seguro de aceitar.
- Avisos conhecidos do `npm audit` (completo): `vite`/`esbuild`/`vitest` (só servidor de desenvolvimento e testes). Corrigir exige saltos de versão grandes (vite 8, vitest 5, TypeScript 7, plugin-react 6, lucide 1.x); deixar para PRs separados.
- **O workflow nunca rodou num GitHub real.** Foi validado com `actionlint` e simulando as etapas numa pasta limpa.

---

## 15. Segurança e privacidade

- **CSP** em `index.html`: `default-src 'self'`; `connect-src` só `self` e `generativelanguage.googleapis.com`; `img-src 'self' data: blob:`; `media-src 'self' blob:`; sem frames/objetos. **Consequência:** mídia hospedada em outro site (Drive, CDN) é **bloqueada**; precisaria afrouxar a CSP.
- A chave do Gemini fica só no navegador. O app é estático: **não há como esconder uma chave de terceiros no navegador**. Se um dia houver chave de outra API (por exemplo Kalodata), ela precisa ficar no **GitHub Secrets** (tarefa agendada) ou num backend.
- Nada é enviado para servidores nossos. O vídeo da Autoanálise é apagado do Google ao final.
- `react-router` atualizado para a versão 7 por causa de uma vulnerabilidade; `npm audit --omit=dev` dá 0.

---

## 16. Testes

**Unitários (vitest, 172 testes, 11 arquivos):** `src/galeria/galeria.test.ts` (a Galeria), `src/manequins/manequins.test.ts` (a aba Manequins), `src/lib/veo/briefing.test.ts` (os 48 cards, as travas, a narração, o gerador), `src/lib/gemini/gemini.test.ts`, `src/tools/normalize.test.ts`, `src/trendly/trendly.test.ts`, `src/humano/humano.test.ts`, `src/lib/media.test.ts`, `src/lib/mediaSlots.test.ts`, `scripts/media-scan.test.ts`, `scripts/stale.test.ts`.

**De navegador (Playwright em Python, no `testes-e2e.zip`):** **não fazem parte do zip do projeto**; vivem fora dele.

| Script | Cobre |
| --- | --- |
| `run_media_tests.py` | **Bateria principal.** Cria arquivos de exemplo em `public/media`, e roda `e2e_media3.py` e `e2e_trendly2.py` no servidor de desenvolvimento, o build de produção e um **subcaminho** (`/meu-repo/`, como no GitHub Pages); depois apaga os exemplos e refaz o build limpo |
| `e2e.py`, `e2e_video.py` | Painel principal, ferramentas, prompts prontos (pela Galeria), upload de vídeo da Autoanálise (com API simulada) |
| `e2e_media3.py` | Mídia por caminho: nomes, maiúsculas, observador, Mapa, avisos |
| `e2e_trendly2.py` | Fluxos UGC/POV/Provador, avatares, produtos, agente |
| `e2e_vi.py` + `run_vi.py` | Imagem **ou** vídeo em cada card, autoplay, aviso de codec, quadro do vídeo para a IA, camada de clique transparente |
| `e2e_hm.py` + `run_hm.py` | Humanizar IA (divisor com mouse e teclado, presets, comandos, editar, persistência, celular) |
| `e2e_veo.py` + `run_veo.py` | Prompts dos Vídeos **em 2500 × 1260**: largura e colunas, cards compactos em português, área de montagem (campos, destaque do que falta, copiar), clipes extras completos, foto da cena, persistência, gerador com a foto (resposta simulada), celular |
| `e2e_galeria.py` + `run_galeria.py` | Galeria de Prompts em 2500 × 1260, com vídeos de exemplo criados e depois apagados em `public/media/gallery` (106 verificações, incluindo os prompts prontos, a compatibilidade com edições e favoritos antigos e os links antigos) |
| `e2e_a11y.py` (rodar com `TEST_SCRIPT=e2e_a11y.py python3 run_veo.py`; precisa de `npm i axe-core`) | Acessibilidade automática (axe-core) em 21 telas e 4 janelas, mais os títulos de aba. Falha com qualquer violação |
| `e2e_manequins.py` (rodar com `TEST_SCRIPT=e2e_manequins.py python3 run_veo.py`) | Aba Manequins em 2500 × 1260: menu, layout, abas, texto do documento, fala separada, copiar, troca de peça, manequim masculino, IA das falas, persistência, celular |
| `e2e_layout.py` + `run_layout.py` | **18 rotas** (inclui `#/galeria`) em 2500 × 1260 e 1366 × 900: o conteúdo ocupa toda a largura e não há rolagem lateral; Reels Studio com 3 cards grandes e capa sem legenda repetida; Configurações em grade |
| `shots_*.py`, `run_hm_shots.py`, `shots_veo.py`, `shots_wide.py`, `shots_ai.py`, `shots_mq.py`, `shots_galeria.py` (com `run_galeria_shots.py`), `shots_prontos.py` | Geram as capturas de tela mostradas ao usuário |

- Todos usam a **API do Google simulada** (`page.route`), nunca uma chave real.
- Os scripts têm **caminhos e portas fixos** (`/home/claude/ppv`, 5190 a 5250). Ajuste antes de usar em outro ambiente. `e2e.py` e `e2e_video.py` têm a porta fixa 5193 (use `sed` para trocar).
- Requisitos: Node 22, Python 3 com `playwright` + Chromium, `ffmpeg` (com `libvpx-vp9`), `tesseract` (só para analisar vídeos de referência).

---

## 17. Decisões de conteúdo e política

- **API privada de terceiros:** o app **não acessa** a API/back-end privado de outros produtos (ex.: Trendly). O site deles bloqueia acesso automático e usar a API sem autorização é problema de termos.
- **Textos de terceiros:** os prompts das bibliotecas e do Humanizar IA foram **escritos por nós** como ponto de partida; não foram copiados de sites.
- **Imagens de terceiros:** nenhuma foto de pessoas, capas ou avatares dos sites de referência foi incluída. O usuário coloca as dele.
- **Avatares:** só fotos do próprio usuário, de quem autorizou ou personagens fictícios criados por IA. Os avatares-base **não têm foto**.
- **Conteúdo gerado por IA:** lembretes para **rotular como conteúdo de IA** (Hacks, Humanizar IA).
- **Hacks:** são entretenimento; as regras da seção 10.2 são **obrigatórias** nos prompts. Falas-isca (pedir seguir em troca de afeto) e alegações de saúde ficam de fora. *Inicialmente eu havia recusado essa parte e depois a implementei com essas regras.*
- **Prompts gerais:** sem promessas de resultado, sem alegações médicas, sem preço inventado.

---

## 18. O que NÃO foi verificado (leia antes de confiar)

- **Nenhuma chamada real ao Gemini.** Tudo foi testado contra uma simulação do formato da API. O primeiro uso com uma chave real pode exigir ajustes (formato da resposta, nomes de modelos, limites de cota). As mensagens de erro foram feitas para dizer o motivo.
- **Upload de vídeo da Autoanálise:** testado só com a simulação do fluxo (iniciar, enviar, esperar, gerar, apagar).
- **Reprodução de MP4 H.264:** o Chromium de teste **não toca H.264**; só o **aviso** foi testado para MP4. Os vídeos que tocaram nos testes eram WebM. Em Chrome/Edge reais o H.264 deve tocar, mas não foi confirmado aqui.
- **Deploy no GitHub:** nunca rodou de verdade (veja a seção 14).
- **Prompts reconstruídos:** nas bibliotecas "Prompts dos Vídeos" e "Prompts Prontas" os vídeos só mostravam trechos; o resto é meu. Os textos da Galeria do Trendly e do Humanizar IA também são meus.
- **Interpretações minhas** (o vídeo de referência não mostrava): passo 3 do UGC (reaproveita a tela de cena do Provador), pose "Sentado(a)", Agente IA, Influencer Studio, "Em breve" de várias telas.
- **Humanizar IA:** feito a partir de **uma captura de tela**; o comportamento que não aparece nela é interpretação minha.
- **Produtos de exemplo** não são dados reais de vendas.
- **Texto desatualizado no código:** a tela "Em breve" do **Radar de Produto** (`data/catalog.ts`, objeto `SOON.radar`) afirma que a Kalodata é "paga e sem acesso aberto". Isso **não foi verificado** (a Kalodata tem um "Centro Aberto" com API paga por créditos). Corrigir.

---

## 19. Lições e armadilhas (já custaram tempo)

1. **`mkdir -p a/{b,c}` no `sh` não expande as chaves** e cria uma pasta literal `{b,c}`. Criar pasta por pasta (aconteceu três vezes).
2. **Extrair um zip novo por cima de um projeto antigo** deixa arquivos velhos (`App.jsx`, `main.jsx`…). Sempre pasta nova, ou `npm run clean:stale`.
3. **`pkill -f padrão` mata o próprio comando** que o contém. Matar por PID.
4. **Servidor antigo na mesma porta** dá "ALL OK" falso. Usar porta nova e `--strictPort`; conferir que o servidor é o certo.
5. **`<button>` por cima de um card** precisa de `background: transparent; border: 0` (o fundo cinza padrão do navegador **tampou a mídia**). Um teste que só confere "o elemento existe" não pega isso: olhar capturas e checar o estilo calculado.
6. **Testes que leem cedo demais** falham por tempo (imagens com `loading="lazy"`, vídeo que ainda não tocou). Esperar a condição, não um tempo fixo. `wait_for_function` não funciona com a CSP (`unsafe-eval`); use `locator.evaluate`.
7. **Detecção de cenas perde mudanças sutis** em interface escura. Para analisar vídeo de tela: extrair **a cada 2 s**, remover quadros repetidos, usar **OCR em resolução nativa** (`tesseract`, em paralelo, em segundo plano por causa do limite de tempo de comando) e olhar os quadros-chave. **Conferir o hash do arquivo**: o "vídeo novo" já foi o mesmo arquivo três vezes.
8. **Olhar o estado real do repositório antes de implementar.** Já reimplementei, por engano, um recurso que existia (mídia por pasta), sobrescrevi dois arquivos e tive de restaurar a partir do zip anterior (`diff -rq` contra o zip entregue resolve).
9. **Não afirmar o que não vi** (preços, limites, comportamento de sites). Duas afirmações minhas sobre a Kalodata estavam sem base e foram corrigidas na conversa.
10. **Comandos longos** (bateria de testes) estouram o limite de 300 s: rodar em segundo plano (`setsid nohup ... &`) e consultar o log.
11. **`vite.config.js` antigo ganha de `vite.config.ts`.** Por isso os scripts passam `--config vite.config.ts`.
12. **React Router 7** aplica a navegação com uma transição assíncrona: testes que contam elementos logo após navegar devem esperar a contagem correta.
13. **`has-text` do Playwright é uma busca por trecho, sem diferenciar maiúsculas:** `button:has-text('Copiar prompt')` também pega "Copiar Prompt A". Use `get_by_role("button", name=..., exact=True)`.
14. **`cut -c1-N` no terminal parte caracteres acentuados no meio** e o resultado deixa de ser UTF-8 válido (a ferramenta de terminal recusa a saída). Corte em Python.
15. **Estado que "sobra" entre aberturas de um diálogo** aparece por um instante: reinicie ao abrir **e ao fechar**, e libere as URLs de prévia (`URL.revokeObjectURL`).
17. **O projeto pode ter sido alterado fora do que você viu.** Ao retomar, rode `grep`/`diff` antes de editar (aconteceu: um `videoPrompts.ts` importava `buildClipPrompts`, de uma correção parcial que eu não conhecia, e o trecho foi sobrescrito). Compare com o último zip entregue.
18. **Teste layout na tela do usuário** (2500 × 1260), não só em 1366: larguras máximas fixas pareciam normais em tela média e deixavam o conteúdo numa faixa estreita em tela larga.
19. **Texto técnico em inglês com `[campos]` no meio não é interface.** O usuário precisa de campos em português, ajuda curta, o resultado final pronto para colar e uma frase em português dizendo o que cada coisa faz.
30. **Ao mover ou renomear uma página, procure por ela em TODOS os testes** (rota, seletor de card, itens de menu, contagens do painel): quatro testes antigos dependiam da galeria no Trendly.
31. **Mudança de comportamento intencional exige atualizar o teste que garantia o antigo** (o aviso de "arquivo sem card" na galeria virou card novo; o exemplo de nome errado foi para outra pasta, e o teste ganhou a checagem de que a galeria NÃO avisa).
32. **Estado de filtros some ao recarregar a página** (de propósito): o teste que "desmarca" um filtro depois de recarregar na verdade o ativa. Pense no estado inicial após `reload`.
34. **`pkill -f <padrão>` mata o próprio comando** quando o padrão aparece na linha dele (aconteceu de novo). Mate por PID ou use outra porta.
35. **Rode uma auditoria de acessibilidade automática e uma de código morto depois de cada mudança grande**: acharam o que nenhuma captura de tela mostrava (contraste 3,44:1, nome de botão, ordem de títulos, 132 regras de CSS mortas, estilos que só carregavam dentro de outra tela).
36. **CSS dividido por tela (code splitting) esconde dependências:** um estilo usado por um componente compartilhado precisa estar no CSS global, senão some quando a tela é aberta direto.
37. **A galeria mostra 60 cards por vez:** em teste, filtre a coleção antes de procurar um card específico.
38. **Contraste em degradê não é medido pelo axe:** calcule à mão as duas pontas.
33. **Copie a organização, não o conteúdo, de um print de outro produto** (marca, textos, nomes de categoria e prompts são deles); aqui as categorias e os textos são próprios.
26. **Verificadores de texto precisam de flexão:** "sofisticado" não pega "sofisticada". Use padrões (`sofisticad[oa]s?`) e teste com feminino e plural.
27. **`text-transform: uppercase` muda o `innerText` que o Playwright lê** ("VÍDEO 1"). Compare sem diferenciar maiúsculas.
28. **Exemplos que você mesmo mostra ao usuário devem passar no verificador do próprio app** (minhas falas de exemplo tinham 27 e 28 palavras; foram barradas por um `assert` e reescritas).
29. **Um documento do usuário pode prometer o que não cumpre** (22 a 26 palavras, mas as falas têm 14 a 18): mantenha o conteúdo dele, sinalize no app e avise.
24. **Uma regra do briefing aplicada ao pé da letra pode não servir ao fluxo real do usuário** (clipes extras mudos). Ao notar a diferença, ofereça as duas formas e explique a troca; e, se mudar o padrão em uma tela, **alinhe todas as telas** que fazem o mesmo (o gerador em diálogo ficou dizendo o contrário até ser corrigido).
25. **Teste intermitente não é "passou":** rodar de novo várias vezes e, se for leitura antes de carregar, fazer o teste esperar a condição (a lista de modelos em `e2e.py`).
21. **Campo de texto livre recebe o que o usuário acha que cabe nele.** Ajuda curta não basta: valide e avise (ficha técnica na narração, medidas no campo "o que aparece"), e não deixe o texto errado chegar ao resultado final.
22. **"A IA não faz nada" quase sempre significa que a IA não está no fluxo que o usuário usou.** Se existe um gerador bom em outro lugar (o diálogo), traga-o para dentro do fluxo principal em vez de deixar campos manuais.
23. **Repare no que o texto do usuário revela:** a ficha dele tinha uma contradição real (título "Preto Fosco" e ficha "Semi-Brilho"); o briefing manda apontar contradições, e a IA agora faz isso nos "Avisos".
20. **Um texto de ajuda não pode afirmar o que não foi verificado** (escrevi que "o Flow entende melhor inglês" e tive de tirar).

---

## 20. Pendências e próximos passos

### 20.1 "Produtos mais vendidos" e "Selecione o Produto Viral" com dados reais (decisão em aberto)
Hoje o card **"Produtos mais vendidos"** do painel só leva a uma tela "Em breve", e a lista do passo "Produto Viral" é **manual** (Produtos + "Importar lista") com 12 exemplos.

**Opção A: Kalodata (API paga por créditos).** Da página de preços (captura do usuário): chamadas de **ranking** custam `0,1 × arredondado para cima (linhas ÷ 100)` créditos; **detalhes** custam 0,1; imagens do produto 0,01; URL do vídeo 0,5; estatísticas de comentários 1; **saldo de créditos e detalhes de consumo são grátis**. Uma nota diz que **1 crédito ≈ US$ 0,10**, mas "o valor real é determinado pelas regras de compra de pontos". Então 1 ranking por dia (até 100 linhas) ≈ US$ 0,30/mês **(estimativa)**. **Falta saber:** valor mínimo de recarga, se há crédito de boas-vindas, se o ranking filtra **Brasil** e período, os **termos** (se pode exibir os dados), e o **formato real da API** (aba "API": endereço, autenticação, parâmetros, campos). Não inventar endereços.

**Opção B: Apify** (atores de terceiros que leem páginas públicas). Plano gratuito com **US$ 5 de crédito/mês**; o ator "TikTok Trending Products" usa o Top Products do Creative Center, com região e período; outros atores cobram cerca de US$ 2 a 3 por 1.000 resultados e têm limites no plano grátis. **Não confirmado:** cobertura do **Brasil** (alguns citam só EUA/UK/Ásia), se pede cartão, qualidade dos números ("vendidos/dia" é estimativa). Risco: raspagem pode ir contra termos do TikTok e quebrar. **Teste de 5 minutos:** criar conta, rodar o ator escolhendo Brasil.

**Opção C: manual** (já existe): colar uma lista em **Produtos > Importar lista**; ligar o card do painel a essa tela.

**Arquitetura sugerida para A ou B (sem expor chave):** uma **tarefa agendada do GitHub Actions** (1 vez por dia) chama a API com a chave em **Secrets** e grava `public/data/produtos.json`; o app lê esse arquivo no card do painel e no passo "Produto Viral". Cuidado com os termos: o arquivo seria público.

### 20.2 Outras pendências
- **Testar os prompts do formato novo no Veo de verdade** (3 a 4 versões por produto) e ajustar as ações de cada card conforme o resultado. É a única forma de saber se o produto sai idêntico.
- Colocar as **mídias reais** em `public/media/` e conferir no Mapa de mídia.
- Testar com **chave Gemini real** e corrigir o que aparecer.
- Fazer o **primeiro deploy** (Pages > Source: GitHub Actions) e conferir a aba Actions.
- **Dependabot:** aplicar a versão mensal (ou apagar o arquivo).
- Corrigir o **texto desatualizado do Radar** (seção 18).
- "Área do Aluno" e "Radar de Produto" continuam "Em breve": exigem servidor (login, dados externos).
- Se quiser **gerar a imagem realista** no Humanizar IA: avaliar um modelo de imagem do Gemini (disponibilidade e cota gratuita **não verificadas**).
- Possível troca de nome "Humanizar IA" por outro.

---

## 21. Arquivos entregues até agora

| Arquivo | O que é |
| --- | --- |
| `prompt-para-video-v24.zip` | **Versão atual do projeto** (inclui `docs/HISTORICO-DO-PROJETO.md`) |
| `HISTORICO-DO-PROJETO.md` | Este documento |
| `testes-e2e.zip` | Scripts de teste de navegador (fora do projeto) |
| `prompts-videos-tiktok.html` | Primeira versão (página única, 48 prompts) |
| `prints/01..41-*.png` | Capturas de tela da evolução. **15 a 20:** Prompts dos Vídeos e o resto das páginas em **2500 × 1260**. **36 a 41:** o painel sem os 3 cards, a seção Prompts prontos, os vídeos do TikTok com o guia, as pastas das Prompts Prontas e os detalhes de um prompt pronto e de um vídeo. **32 a 35:** a Galeria de Prompts (grade e filtros, detalhes com o lápis ao lado do copiar, editor do prompt, vídeos novos da pasta de mídia; vídeos de exemplo, não os seus). **27 a 31:** a aba Manequins (guia e Passo 1, vídeos com as falas do documento sinalizadas, Passo 2, falas escritas pela IA, e a troca para calça). **24 a 26:** os clipes extras com fala (roteiro completo, clipe 3 com a chamada final, e o modo sem fala). **21 a 23:** o caso da cômoda (ficha colada nos campos errados com avisos, Passo 1 da IA, e o prompt pronto depois que a IA preenche; resposta da IA simulada) |

Versões intermediárias (v1 a v8) foram sendo substituídas; só a mais recente é mantida.

---

## 22. README técnico do projeto

O `README.md` dentro do zip documenta, de forma mais enxuta, como rodar, publicar, conectar o Gemini, a arquitetura, o Trendly, o Humanizar IA e o sistema de mídia. Este arquivo é o **histórico e as decisões**; o README é o **manual de uso**.

---

## 23. Vídeos da Galeria tocam sozinhos (v17)

Os vídeos dos cards da Galeria agora funcionam como um GIF: tocam sozinhos, mudos e em loop enquanto o card está na tela, e pausam fora dela. Quem ativa "reduzir movimento" no sistema continua vendo só o primeiro quadro. Antes, o vídeo só tocava com o mouse em cima. Arquivo: `src/galeria/components/GaleriaCard.tsx`.

---

## 24. Lápis no Mapa de mídia (v18)

Antes, para colocar uma imagem ou vídeo era preciso achar o arquivo, renomear e colar na pasta do exemplo. Agora cada linha do Mapa de mídia tem um lápis (e aceita arrastar e soltar) que envia o arquivo para `public/media/<pasta>/<nome>.<ext>`. Três caminhos, nesta ordem: servidor do `npm run dev` (`scripts/media-upload.ts` + plugin), pasta do projeto escolhida no Chrome/Edge (File System Access API, `src/lib/mediaUpload.ts`) e download com o nome certo. Também mostra miniatura do arquivo atual. Testes: `scripts/media-upload.test.ts`, `src/lib/mediaUpload.test.ts`, `e2e_mapa.py`.

---

## 25. Mídia para prompts criados pelo usuário (v19)

Relato: ao criar um prompt novo ("mesa") não havia como anexar imagem ou vídeo, o card dizia "Coloque o arquivo em ... e faça o commit", e o prompt criado não aparecia no Mapa de mídia. Agora: campo de mídia no "Novo prompt", botão e lápis de mídia na janela de detalhes, botão "Subir vídeo ou imagem" na Galeria (componente `MediaPicker`), prompts do usuário listados no Mapa de mídia, e o tipo do card (vídeo/imagem) segue o arquivo enviado. Os vídeos dos cards tocam sozinhos desde a v17: quem ainda via vídeo parado só ao passar o mouse estava numa versão anterior. Teste: `e2e_novo_prompt.py`.

---

## 26. Vídeo tocando sozinho de verdade (v20)

Relato: mesmo com o mouse em cima, o vídeo do card "mesa" não tocava; era preciso clicar e dar play. Causas tratadas: (1) o `muted` do React não garante o vídeo mudo na hora em que o navegador decide se pode tocar sozinho, e vídeo com áudio mudo-não-confirmado é bloqueado, então o mudo agora é forçado pelo código (`playMuted`); (2) o app obedecia ao "reduzir movimento" do sistema, o que deixava tudo parado sem aviso, então a escolha passou a ser do app (botão Movimento na Galeria e opção em Configurações, ligada por padrão); (3) se o navegador recusar, o card mostra um ▶. Os testes antigos usavam vídeo sem áudio e por isso não pegavam o problema: o novo `e2e_autoplay.py` usa vídeo com áudio, política de autoplay do Chrome ligada e sistema com "reduzir movimento". Também atualizei as asserções antigas "sem upload" de `e2e_media3.py`, que passaram a contradizer o envio de mídia (v18/v19).

---

## 27. Salvar no projeto (v21)

Relato: o site no GitHub Pages mostrava 125 prompts e o local 137. Os 12 a mais eram prompts criados e editados no navegador (localStorage, separado por endereço). Como o uso é só do dono, a decisão foi gravar esses dados no próprio projeto: `src/data/userData.json`, importado no build, então vale no GitHub Pages e na Vercel sem servidor. O botão **Salvar no projeto** usa o servidor do `npm run dev` (`/__data/save`, `scripts/user-data.ts`); sem ele, **Baixar userData.json**. Regras: só prompts, edições, favoritos e produtos entram (lista em `src/lib/userDataKeys.ts`; chave do Gemini e histórico ficam de fora, com teste); navegador sem alterações adota o arquivo do projeto; alterações locais com projeto mais novo geram a pergunta de qual versão vale. Testes: `scripts/user-data.test.ts` e `e2e_userdata.py` (inclui um segundo navegador limpo vendo o prompt salvo).

---

## 28. Lápis no site publicado (v22)

Relato: na Vercel/GitHub Pages o lápis dava o erro "Failed to execute 'showDirectoryPicker' on 'Window': Must be handling a user gesture". Causa: fora do `npm run dev`, o app tentava abrir o seletor de pasta do navegador **depois** de a pessoa escolher o arquivo, e o navegador só libera esse seletor logo após um clique (o clique já tinha sido gasto no seletor de arquivo). Além disso, um site publicado não escreve no projeto de qualquer jeito. Decisão: o modo "escolher a pasta do projeto" foi removido. Agora: com `npm run dev` grava direto em `public/media`; no site publicado baixa o arquivo com o nome certo e avisa em qual pasta colocar e que é preciso fazer o commit. Teste: `e2e_publicado.py` (roda no build/preview).

---

## 29. Monitoramento, visual azul, Geradores de Prompt e títulos editáveis (v23)

Pedido: seguir com o monitoramento combinado, deixar o layout mais profissional (o painel estava muito rosa), juntar os geradores num lugar só, trocar o nome "Trendly" por "Tendências" e colocar um lápis nos títulos para editar o nome.

**Geradores de Prompt.** O painel mostrava 9 cards soltos de IA (POV, UGC, Influencer, Copy, Análise de Produto, Autoanálise de Vídeo, Headlines, Defesa, Crescimento). Agora há **um card só** ("Geradores de Prompt", `#/geradores`, `src/pages/GeneratorsPage.tsx`) que abre uma página com os 9. O painel caiu de 15 para 8 cards. A busca do painel ainda acha os geradores (campo `keywords`). Os endereços antigos `#/ferramenta/<id>` continuam. No menu lateral o item fica depois da Galeria, para manter "Humanizar IA" logo abaixo de Tendências e "Galeria" logo abaixo de Manequins.

**Painel sem repetição (pedido depois de ver o resultado).** Ao ver o painel pronto, o usuário notou que o menu lateral e os cards do meio mostravam as mesmas opções e pediu para juntar as ideias de enxugar o menu e de dar ao painel um conteúdo próprio, "sem repetir". Decisão: cada destino aparece num lugar só. Menu: Painel, Geradores de Prompt, Galeria de Prompts, Configurações. Painel: resumo (Gemini, favoritos, editados, Diagnóstico), **Continue de onde parou** (`src/lib/recent.ts`, últimas 6 ferramentas e prompts), atalhos e "Mais ferramentas" (Tendências, Humanizar IA, Manequins e "Em breve"). A Galeria ganhou os links `?p=` (abre um prompt), `?v=` (filtro) e `?novo=1`. Um erro meu no caminho: ao tirar os geradores do catálogo, o título da aba deles virou "Página não encontrada"; corrigido e coberto por teste.

**Tendências.** Só o nome visível mudou (painel, menu, barra, títulos de aba, textos e o assistente de chat). Pastas e rotas continuam `trendly`, para não quebrar links, favoritos e dados salvos.

**Lápis nos títulos.** Antes só os prompts criados pelo usuário tinham título editável. Agora todos (os embutidos, vídeos, movimentos e galeria). Para os embutidos o título entra nas "edições" (`overrides:<coleção>`), então o original continua intacto e há **Restaurar nome**. O "Editado" passou a considerar o título. Arquivos: `GaleriaDetail.tsx` (componente `TitleEditor` no cabeçalho, via `Modal head`), `useLibrary.ts`, `galeria.ts`, `GaleriaPage.tsx`. Renomear e editar o texto não se apagam entre si.

**Visual.** Paleta única azul-escuro no lugar de rosa e laranja: tokens `--accent*` (com `--pink*` mantidos como apelidos), fundo e menu lateral sem gradiente colorido, cards sólidos com borda sutil, botão primário `#2563eb` (contraste 5,2:1 com branco), Humanizar IA e capas dos estilos na mesma família. O axe-core continuou com zero violações.

**Monitoramento, camada 1.** `.github/workflows/uptime.yml`, a cada 30 minutos: `scripts/check-site.mjs` abre o site, confere se é o app e se os arquivos carregam (3 tentativas); se falhar, abre/atualiza a issue "Site fora do ar" e a fecha quando volta. Endereço pela variável `SITE_URL` ou, na falta dela, pelo GitHub Pages. O build agora gera `health.json` (versão e hora).

**Monitoramento, camada 2.** Configurações > Diagnóstico (`src/lib/diagnostics.ts`, `DiagnosticsPanel.tsx`, `ErrorBoundary.tsx`): registra erro de tela, falha do Gemini, vídeo que não toca e falha de envio, agrupando repetições; mostra versão, armazenamento e compara com a versão publicada; copia um relatório. Decisão de privacidade: tudo local (`ppv:diag:events`), fora do `userData.json`, e a chave do Gemini é removida de qualquer texto antes de guardar (testado com uma chave dentro da mensagem de erro).

**Testes.** 216 unitários (novos: diagnóstico, catálogo, continue de onde parou, verificação do site, renomear título, títulos dos geradores) e o novo `e2e_v23.py` (geradores, nome, lápis em 4 tipos de prompt, restaurar, Esc, Diagnóstico com chave simulada). Scripts antigos ajustados para o painel de 6 cards, o menu enxuto e o nome Tendências. Bateria completa verde (media, galeria, veo, manequins, a11y com zero violações, vi, hm, layout, e2e, e2e_video, mapa, novo prompt, autoplay, userdata, publicado e v23). Na primeira rodada a bateria de mídia deu uma falha que não se repetiu na segunda (já era conhecida como instável no envio de produto).

**Limites.** A verificação agendada só funciona depois de o repositório estar no GitHub com Actions ligado; ela avisa por issue (o GitHub manda e-mail se as notificações estiverem ligadas). O Diagnóstico só vê este navegador, não o de outras pessoas.

---

## 30. Filtros da Galeria que se somavam sem avisar (v24)

Relato (com print): na Galeria, "Prompts dos Vídeos do TikTok" mostrava 48, mas ao selecioná-lo não aparecia nenhum card, e não havia nenhum filtro à vista bloqueando. Causa: no print o filtro **"Editados por mim"** também estava ligado. Os filtros da Galeria sempre se somaram, só que (1) o número ao lado de cada item era o total geral, ignorando os outros filtros, e (2) nada mostrava quais filtros estavam ligados. Era falha de comunicação da tela, não de dados.

Correção: contagens "em camadas" (`facetCounts`: cada grupo mostra quanto sobraria com os demais filtros ligados, então o número sempre bate com o resultado do clique), faixa **Filtros ligados** com etiquetas removíveis e "Limpar todos" (`activeFilters` e `withoutFilter`), e botão **Limpar filtros** na tela vazia. Testes: 4 unitários novos (220 no total) e um bloco novo no `e2e_v23.py` que reproduz exatamente o caso do print. Bateria da Galeria, vídeos do TikTok, acessibilidade, manequins e layout verdes.

---

## 31. Aba Progresso Semanal (v25)

Pedido: o usuário anexou um zip de um dashboard em HTML/JS puro (`dashbord-main`) e pediu para aplicar a funcionalidade dele numa nova aba **Progresso Semanal**, logo abaixo de "Galeria de Prompts", e melhorar o que o zip faz.

**O que o zip fazia.** 6 metas fixas (4 reais e 2 "acrescente uma meta pessoal"), calendário do mês com uma caixa por meta e por dia, barra de "Progresso Semanal" que na verdade media o **mês inteiro**, barras por dia da semana, frase motivacional do dia lida de `quotes.json` e navegação de mês. Limitações: metas não editáveis, dias futuros contavam como não cumpridos, nada de sequência, sem teclado/leitor de tela cuidados, um arquivo `products.js` solto que não era usado.

**O que a aba faz agora** (`src/progresso/`, rota `#/progresso`, item no menu logo após a Galeria, entrada `inMenu` no catálogo para não repetir como card no painel):
- **Semana de verdade** (domingo a sábado) com navegação anterior/próxima/"Esta semana", percentual da semana, barras por dia e tabela metas × dias.
- **Dias futuros travados e fora do cálculo**: o percentual conta só os dias até hoje, então a semana não "começa em 0%" injustamente.
- **Metas editáveis**: adicionar, renomear, reordenar, excluir (apaga só as marcações da meta), até 12. As 4 metas iniciais vêm do zip (Stories, Reels, produzir Reels do dia seguinte, métricas da Shopee).
- **Marcar o dia todo**, **Limpar a semana**, **sequência** de dias com todas as metas (hoje aberto não quebra), percentual por meta e do mês.
- **Mapa do mês** (um quadrado por dia, mais forte quanto mais metas; clique abre a semana do dia), **média por dia da semana** (o que as barras do zip mostravam) e o melhor dia.
- **Frase do dia**: 57 frases do zip sem repetidas (`src/progresso/data/quotes.ts`), uma por dia, sem `fetch`.
- **Painel**: novo bloco "Metas de hoje" no resumo.
- **Dados**: `progresso:goals` e `progresso:done` (localStorage `ppv:`) entram na lista de `userDataKeys.ts`, então vão para o `userData.json` com "Salvar no projeto" como os demais dados do usuário.
- Acessibilidade: tabela com legenda e cabeçalhos, cada caixa com nome "meta, dia", rótulos acessíveis conferem com o texto visível (o axe pegou um caso e foi corrigido). Zero violações.

**Decisões.** Lógica pura em `src/progresso/lib/progresso.ts` (testável, sem DOM). Data local sem fuso (meio-dia) para não escorregar de dia. Não foram aproveitados `products.js`/`data.js` do zip (não eram usados).

**Testes.** 238 unitários (15 novos de lógica, 3 de chaves sincronizáveis, catálogo e título ajustados) e `e2e_progresso.py` (menu, marcar, persistência, dias futuros, semana anterior, metas, mapa, painel). `e2e_galeria`/`e2e_v23` ajustados para o menu de 5 itens e o painel de 5 blocos; `e2e_v23` agora lê a versão do `package.json` (estava fixa em 6.7.0 e passou despercebida na v24). Bateria completa verde.


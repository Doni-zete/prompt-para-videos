/** Baixa bytes como arquivo .xlsx (ou outro tipo) pelo navegador. */
export function downloadBytes(bytes: Uint8Array, name: string, type = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"): void {
  const url = URL.createObjectURL(new Blob([bytes as BlobPart], { type }));
  const a = document.createElement("a");
  a.href = url;
  a.download = name;
  a.click();
  setTimeout(() => URL.revokeObjectURL(url), 1000);
}
